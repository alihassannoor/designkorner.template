<h1>You hav a new Contact mail via the Conatct form</h1>

<div>
    {{$bodymessage}}
    {{-- {!! $bodymessage !!} --}}
</div> 