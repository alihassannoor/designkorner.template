@extends('layouts.settings.templates')
@push('css_lib')
    <!-- iCheck -->
    <link rel="stylesheet" href="{{asset('vendor/icheck-bootstrap/icheck-bootstrap.min.css')}}">
    <!-- select2 -->
    <link rel="stylesheet" href="{{asset('vendor/select2/css/select2.min.css')}}">
    <link rel="stylesheet" href="{{asset('vendor/select2-bootstrap4-theme/select2-bootstrap4.min.css')}}">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="{{asset('vendor/summernote/summernote-bs4.min.css')}}">
    {{--dropzone--}}
    <link rel="stylesheet" href="{{asset('vendor/dropzone/min/dropzone.min.css')}}">

    
{{--   
<link rel="stylesheet"
    href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"> --}}
@endpush
@section('settings_title',trans('lang.user_table'))
@section('settings_content')
    @include('flash::message')
    @include('adminlte-templates::common.errors')
    <div class="clearfix"></div>
    <div class="card shadow-sm">
        <div class="card-header">
            <ul class="nav nav-tabs d-flex flex-row align-items-start card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link " href="{!! url('settings/templates/sms') !!}"><i class="fas fa-envelope mr-2"></i>{{trans('lang.app_setting_sms_templates')}}@if(setting('mail_driver') === 'smtp')
                            <span class="badge ml-2 badge-success"></span>@endif</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="{!! url('settings/templates/mail') !!}"><i class="fas fa-envelope-o mr-2"></i>{{trans('lang.app_setting_mails_templates')}}@if(setting('mail_driver') === 'mailgun')
                            <span class="badge ml-2 badge-success"></span>@endif
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{!! url('settings/templates/notifications') !!}"><i class="fas fa-envelope-o mr-2"></i>{{trans('lang.app_setting_notification_templates')}}@if(setting('mail_driver') === 'sparkpost')
                            <span class="badge ml-2 badge-success"></span>@endif
                    </a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            
            <div class="row">
            <div class="col-6">
                <div class="card shadow-sm">
        <div class="card-header">
            <ul class="nav nav-tabs d-flex flex-md-row flex-column-reverse align-items-start card-header-tabs">
                <div class="d-flex flex-row">
                    <li class="nav-item">
                        <a class="nav-link active" href="{!! url()->current() !!}"><i class="fas fa-list mr-2"></i>{{trans('lang.user_table')}}</a>
                    </li>
                    
                </div><br><br>
                
            </ul>
            <form id="form1" runat="server">
            
                <table class="table" id="table">
                    <thead>
                       <tr>
                           <th align="left"><input type="checkbox" id="checkAll"></th>
                           <th>#</th>
                           <th>Name</th>
                           <th>Email</th>
                       </tr>
                   </thead>
                   <tbody>
                       @foreach ($u as $users)
                       <tr>
                           <td><input value="{{ $users->email }}" type="checkbox" ></td>
                           <td>{{ $users->id }}</td>
                           <td>{{ $users->name }}</td>
                           <td>{{ $users->email }}</td>
                       </tr>
                           
                       @endforeach
                   </tbody>
               </table>
        </form>
        <button class="btn btn-primary btn-lg">Add Contact</button>
            {{-- {{$u->links()}} --}}
        </div>
        <div class="card-body">
            
            <div class="clearfix"></div>
        </div>
    </div>
            </div>
            <div class="col-6">
                <div class="card shadow-sm">
        <div class="card-header">
            <ul class="nav nav-tabs d-flex flex-md-row flex-column-reverse align-items-start card-header-tabs">
                <div class="d-flex flex-row">
                    <li class="nav-item">
                        <a class="nav-link" href="{!! url('settings/templates/mail') !!}"><i class="fas fa-list mr-2"></i>{{trans('lang.mail_send')}}</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="{!! url()->current() !!}"><i class="fas fa-plus mr-2"></i>{{trans('lang.template_create')}}</a>
                    </li>
                    
                </div>
                
            </ul>
        </div>
        <div class="card-body">
            
            <div class="clearfix"></div>
            <form action="{!! url('/settings/templates/store_mail_templates') !!}" method="GET">
                @csrf 
                <label for="title">Template Title</label>
                <input type="text" name="title" class="form-control">

<br>
<label for="message">Template</label>
<textarea name="message" id="editor" rows="10" cols="10" class="form-control" ></textarea>
                <br>
                <input type="submit" class="btn btn-success btn-md btn-block" value="Add Template" name="" id="">
            </form> 
        </div>
    </div>
            </div>
        </div>

        </div>
    </div>
    </div>
    @include('layouts.media_modal',['collection'=>null])
@endsection
@push('scripts_lib')
    <!-- iCheck -->

    <!-- select2 -->
    <script src="{{asset('vendor/select2/js/select2.full.min.js')}}"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="{{asset('vendor/summernote/summernote.min.js')}}"></script>
    {{--dropzone--}}
    <script src="{{asset('vendor/dropzone/min/dropzone.min.js')}}"></script>
    <script>
        Dropzone.autoDiscover = false;
        var dropzoneFields = [];
    </script>


    <script src="//code.jquery.com/jquery-1.12.3.js"></script>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script
    src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
   
{{-- DATA TABLES FUNCTION --}}
   <script>
    $(document).ready(function () { 
    var oTable = $('#table').dataTable({
        stateSave: true
    });
// MULTi PAGES CHECK FUNCTION
    var allPages = oTable.fnGetNodes();

    $('body').on('click', '#checkAll', function () {
        if ($(this).hasClass('allChecked')) {
            $('input[type="checkbox"]', allPages).prop('checked', false);
        } else {
            $('input[type="checkbox"]', allPages).prop('checked', true);
        }
        $(this).toggleClass('allChecked');
    });
    $(".add").click(function(){

if(confirm("Are you sure you want to Add"))
{
    var id =[];
    $(":checkbox:checked",allPages).each(function(i){
        id[i] =$(this).val();
    })
    if(id.length==0){
        alert("Atleast check one");
    }else{
        
    document.getElementById('tofield').value=id;
    }
}
else {
return false;
}
});
});
   </script> 
   

    {{-- CK EDITORS SCRIPTS AND FUNCTION     --}}
    <script src="https://cdn.ckeditor.com/ckeditor5/29.0.0/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>
        
@endpush
